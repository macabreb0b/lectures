require 'test_helper'

class MasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
