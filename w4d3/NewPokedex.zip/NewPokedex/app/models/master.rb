class Master < ActiveRecord::Base
  has_many :pokemons
end
